#!/usr/bin/env python3
"""
报价规则库 - AI参考报价
已优化：降低15%促进订单
数据来源：维修行业经验 + 闲鱼二手市场参考
更新时间：2026-04-22
"""

from datetime import datetime

# 元数据
METADATA = {
    'version': '2.0',
    'updated_at': '2026-04-22',
    'source': '维修行业经验 + 闲鱼二手市场参考',
    'note': 'AI参考报价，实际以检测后报价为准',
    'confidence_method': '基于维修商家采购价和市场行情估算',
}

# 置信度说明
# 0.9: 热门机型，价格准确
# 0.7: 常见机型，价格较准
# 0.5: 小众机型，价格参考
# 0.3: 估算价格，需核实

# 配件价格数据库（AI参考价，已优化促进订单）

# 配件价格数据库（AI参考价，已优化促进订单）
PRICING_RULES = {
    # ==================== Mini 系列 ====================
    'Mini': {
        '云台电机': {'cost': 95, 'suggest_price': 160, 'code': 'P-M-YT-DJ-001'},
        '云台排线': {'cost': 25, 'suggest_price': 55, 'code': 'P-M-YT-PX-001'},
        '云台整体': {'cost': 420, 'suggest_price': 620, 'code': 'P-M-YT-ZT-001'},
        '图传模块': {'cost': 180, 'suggest_price': 300, 'code': 'P-M-TC-001'},
        '电池': {'cost': 120, 'suggest_price': 199, 'code': 'P-M-DC-001'},
        '机臂': {'cost': 55, 'suggest_price': 95, 'code': 'P-M-JB-001'},
        '桨叶': {'cost': 15, 'suggest_price': 35, 'code': 'P-M-JY-001'},
        '遥控器': {'cost': 180, 'suggest_price': 300, 'code': 'P-M-YK-001'},
    },
    'Mini SE': {
        '云台电机': {'cost': 95, 'suggest_price': 160, 'code': 'P-MSE-YT-DJ-001'},
        '云台排线': {'cost': 25, 'suggest_price': 55, 'code': 'P-MSE-YT-PX-001'},
        '云台整体': {'cost': 420, 'suggest_price': 620, 'code': 'P-MSE-YT-ZT-001'},
        '图传模块': {'cost': 180, 'suggest_price': 300, 'code': 'P-MSE-TC-001'},
        '电池': {'cost': 120, 'suggest_price': 199, 'code': 'P-MSE-DC-001'},
        '机臂': {'cost': 55, 'suggest_price': 95, 'code': 'P-MSE-JB-001'},
        '桨叶': {'cost': 15, 'suggest_price': 35, 'code': 'P-MSE-JY-001'},
    },
    'Mini 2': {
        '云台电机': {'cost': 110, 'suggest_price': 180, 'code': 'P-M2-YT-DJ-001'},
        '云台排线': {'cost': 28, 'suggest_price': 60, 'code': 'P-M2-YT-PX-001'},
        '云台整体': {'cost': 480, 'suggest_price': 700, 'code': 'P-M2-YT-ZT-001'},
        '图传模块': {'cost': 200, 'suggest_price': 330, 'code': 'P-M2-TC-001'},
        '电池': {'cost': 140, 'suggest_price': 230, 'code': 'P-M2-DC-001'},
        '机臂': {'cost': 65, 'suggest_price': 110, 'code': 'P-M2-JB-001'},
        '桨叶': {'cost': 18, 'suggest_price': 38, 'code': 'P-M2-JY-001'},
    },
    'Mini 2 SE': {
        '云台电机': {'cost': 110, 'suggest_price': 180, 'code': 'P-M2SE-YT-DJ-001'},
        '云台排线': {'cost': 28, 'suggest_price': 60, 'code': 'P-M2SE-YT-PX-001'},
        '云台整体': {'cost': 480, 'suggest_price': 700, 'code': 'P-M2SE-YT-ZT-001'},
        '图传模块': {'cost': 200, 'suggest_price': 330, 'code': 'P-M2SE-TC-001'},
        '电池': {'cost': 140, 'suggest_price': 230, 'code': 'P-M2SE-DC-001'},
        '机臂': {'cost': 65, 'suggest_price': 110, 'code': 'P-M2SE-JB-001'},
    },
    'Mini 3': {
        '云台电机': {'cost': 125, 'suggest_price': 200, 'code': 'P-M3-YT-DJ-001'},
        '云台排线': {'cost': 30, 'suggest_price': 65, 'code': 'P-M3-YT-PX-001'},
        '云台整体': {'cost': 550, 'suggest_price': 800, 'code': 'P-M3-YT-ZT-001'},
        '图传模块': {'cost': 240, 'suggest_price': 380, 'code': 'P-M3-TC-001'},
        '电池': {'cost': 160, 'suggest_price': 260, 'code': 'P-M3-DC-001'},
        '机臂': {'cost': 75, 'suggest_price': 130, 'code': 'P-M3-JB-001'},
        '桨叶': {'cost': 22, 'suggest_price': 42, 'code': 'P-M3-JY-001'},
    },
    'Mini 3 Pro': {
        '云台电机': {'cost': 145, 'suggest_price': 230, 'code': 'P-M3P-YT-DJ-001'},
        '云台排线': {'cost': 35, 'suggest_price': 80, 'code': 'P-M3P-YT-PX-001'},
        '云台整体': {'cost': 680, 'suggest_price': 980, 'code': 'P-M3P-YT-ZT-001'},
        '图传模块': {'cost': 280, 'suggest_price': 450, 'code': 'P-M3P-TC-001'},
        '电调': {'cost': 120, 'suggest_price': 200, 'code': 'P-M3P-DD-001'},
        '飞控': {'cost': 380, 'suggest_price': 580, 'code': 'P-M3P-FK-001'},
        '电池': {'cost': 180, 'suggest_price': 299, 'code': 'P-M3P-DC-001'},
        '机臂': {'cost': 85, 'suggest_price': 150, 'code': 'P-M3P-JB-001'},
        '桨叶': {'cost': 25, 'suggest_price': 49, 'code': 'P-M3P-JY-001'},
        '摄像头': {'cost': 450, 'suggest_price': 680, 'code': 'P-M3P-SX-001'},
        '镜头': {'cost': 320, 'suggest_price': 520, 'code': 'P-M3P-JT-001'},
        '外壳': {'cost': 120, 'suggest_price': 200, 'code': 'P-M3P-WK-001'},
    },
    'Mini 4 Pro': {
        '云台电机': {'cost': 155, 'suggest_price': 250, 'code': 'P-M4P-YT-DJ-001'},
        '云台排线': {'cost': 38, 'suggest_price': 85, 'code': 'P-M4P-YT-PX-001'},
        '云台整体': {'cost': 720, 'suggest_price': 1050, 'code': 'P-M4P-YT-ZT-001'},
        '图传模块': {'cost': 320, 'suggest_price': 500, 'code': 'P-M4P-TC-001'},
        '电池': {'cost': 200, 'suggest_price': 330, 'code': 'P-M4P-DC-001'},
        '机臂': {'cost': 95, 'suggest_price': 165, 'code': 'P-M4P-JB-001'},
        '桨叶': {'cost': 28, 'suggest_price': 55, 'code': 'P-M4P-JY-001'},
        '摄像头': {'cost': 520, 'suggest_price': 780, 'code': 'P-M4P-SX-001'},
    },
    'Mini 4 K': {
        '云台电机': {'cost': 125, 'suggest_price': 200, 'code': 'P-M4K-YT-DJ-001'},
        '云台排线': {'cost': 30, 'suggest_price': 65, 'code': 'P-M4K-YT-PX-001'},
        '云台整体': {'cost': 550, 'suggest_price': 800, 'code': 'P-M4K-YT-ZT-001'},
        '图传模块': {'cost': 240, 'suggest_price': 380, 'code': 'P-M4K-TC-001'},
        '电池': {'cost': 160, 'suggest_price': 260, 'code': 'P-M4K-DC-001'},
        '机臂': {'cost': 75, 'suggest_price': 130, 'code': 'P-M4K-JB-001'},
    },

    # ==================== Air 系列 ====================
    'Air 2': {
        '云台电机': {'cost': 130, 'suggest_price': 210, 'code': 'P-A2-YT-DJ-001'},
        '云台排线': {'cost': 32, 'suggest_price': 70, 'code': 'P-A2-YT-PX-001'},
        '云台整体': {'cost': 580, 'suggest_price': 850, 'code': 'P-A2-YT-ZT-001'},
        '图传模块': {'cost': 250, 'suggest_price': 400, 'code': 'P-A2-TC-001'},
        '电池': {'cost': 170, 'suggest_price': 280, 'code': 'P-A2-DC-001'},
        '机臂': {'cost': 80, 'suggest_price': 140, 'code': 'P-A2-JB-001'},
    },
    'Air 2s': {
        '云台电机': {'cost': 140, 'suggest_price': 225, 'code': 'P-A2S-YT-DJ-001'},
        '云台排线': {'cost': 34, 'suggest_price': 75, 'code': 'P-A2S-YT-PX-001'},
        '云台整体': {'cost': 620, 'suggest_price': 900, 'code': 'P-A2S-YT-ZT-001'},
        '图传模块': {'cost': 270, 'suggest_price': 430, 'code': 'P-A2S-TC-001'},
        '电池': {'cost': 190, 'suggest_price': 310, 'code': 'P-A2S-DC-001'},
        '机臂': {'cost': 85, 'suggest_price': 150, 'code': 'P-A2S-JB-001'},
        '摄像头': {'cost': 480, 'suggest_price': 720, 'code': 'P-A2S-SX-001'},
    },
    'Air 3': {
        '云台电机': {'cost': 165, 'suggest_price': 260, 'code': 'P-A3-YT-DJ-001'},
        '云台排线': {'cost': 45, 'suggest_price': 95, 'code': 'P-A3-YT-PX-001'},
        '云台整体': {'cost': 850, 'suggest_price': 1280, 'code': 'P-A3-YT-ZT-001'},
        '图传模块': {'cost': 350, 'suggest_price': 550, 'code': 'P-A3-TC-001'},
        '电调': {'cost': 150, 'suggest_price': 250, 'code': 'P-A3-DD-001'},
        '飞控': {'cost': 480, 'suggest_price': 720, 'code': 'P-A3-FK-001'},
        '电池': {'cost': 220, 'suggest_price': 359, 'code': 'P-A3-DC-001'},
        '机臂': {'cost': 120, 'suggest_price': 200, 'code': 'P-A3-JB-001'},
        '桨叶': {'cost': 35, 'suggest_price': 69, 'code': 'P-A3-JY-001'},
    },
    'Air 3S': {
        '云台电机': {'cost': 175, 'suggest_price': 280, 'code': 'P-A3S-YT-DJ-001'},
        '云台排线': {'cost': 48, 'suggest_price': 100, 'code': 'P-A3S-YT-PX-001'},
        '云台整体': {'cost': 900, 'suggest_price': 1350, 'code': 'P-A3S-YT-ZT-001'},
        '图传模块': {'cost': 380, 'suggest_price': 600, 'code': 'P-A3S-TC-001'},
        '电池': {'cost': 240, 'suggest_price': 390, 'code': 'P-A3S-DC-001'},
        '机臂': {'cost': 130, 'suggest_price': 220, 'code': 'P-A3S-JB-001'},
    },

    # ==================== Mavic 系列 ====================
    'Mavic 2': {
        '云台电机': {'cost': 180, 'suggest_price': 290, 'code': 'P-M2-YT-DJ-001'},
        '云台排线': {'cost': 42, 'suggest_price': 90, 'code': 'P-M2-YT-PX-001'},
        '云台整体': {'cost': 800, 'suggest_price': 1200, 'code': 'P-M2-YT-ZT-001'},
        '图传模块': {'cost': 320, 'suggest_price': 500, 'code': 'P-M2-TC-001'},
        '电池': {'cost': 260, 'suggest_price': 420, 'code': 'P-M2-DC-001'},
        '机臂': {'cost': 100, 'suggest_price': 180, 'code': 'P-M2-JB-001'},
    },
    'Mavic 2 Pro': {
        '云台电机': {'cost': 200, 'suggest_price': 320, 'code': 'P-M2P-YT-DJ-001'},
        '云台排线': {'cost': 45, 'suggest_price': 95, 'code': 'P-M2P-YT-PX-001'},
        '云台整体': {'cost': 900, 'suggest_price': 1350, 'code': 'P-M2P-YT-ZT-001'},
        '图传模块': {'cost': 350, 'suggest_price': 550, 'code': 'P-M2P-TC-001'},
        '摄像头': {'cost': 680, 'suggest_price': 1000, 'code': 'P-M2P-SX-001'},
        '电池': {'cost': 280, 'suggest_price': 450, 'code': 'P-M2P-DC-001'},
    },
    'Mavic 2 Zoom': {
        '云台电机': {'cost': 190, 'suggest_price': 300, 'code': 'P-M2Z-YT-DJ-001'},
        '云台整体': {'cost': 850, 'suggest_price': 1280, 'code': 'P-M2Z-YT-ZT-001'},
        '摄像头': {'cost': 600, 'suggest_price': 900, 'code': 'P-M2Z-SX-001'},
        '电池': {'cost': 270, 'suggest_price': 430, 'code': 'P-M2Z-DC-001'},
    },
    'Mavic 3': {
        '云台电机': {'cost': 220, 'suggest_price': 350, 'code': 'P-M3-YT-DJ-001'},
        '云台整体': {'cost': 1200, 'suggest_price': 1680, 'code': 'P-M3-YT-ZT-001'},
        '图传模块': {'cost': 450, 'suggest_price': 680, 'code': 'P-M3-TC-001'},
        '飞控': {'cost': 650, 'suggest_price': 980, 'code': 'P-M3-FK-001'},
        '电池': {'cost': 380, 'suggest_price': 599, 'code': 'P-M3-DC-001'},
    },
    'Mavic 3 Pro': {
        '云台电机': {'cost': 250, 'suggest_price': 400, 'code': 'P-M3P-YT-DJ-001'},
        '云台整体': {'cost': 1500, 'suggest_price': 2200, 'code': 'P-M3P-YT-ZT-001'},
        '图传模块': {'cost': 500, 'suggest_price': 780, 'code': 'P-M3P-TC-001'},
        '摄像头': {'cost': 1200, 'suggest_price': 1800, 'code': 'P-M3P-SX-001'},
        '电池': {'cost': 420, 'suggest_price': 650, 'code': 'P-M3P-DC-001'},
    },
    'Mavic 3 Classic': {
        '云台电机': {'cost': 230, 'suggest_price': 370, 'code': 'P-M3C-YT-DJ-001'},
        '云台整体': {'cost': 1300, 'suggest_price': 1900, 'code': 'P-M3C-YT-ZT-001'},
        '图传模块': {'cost': 470, 'suggest_price': 720, 'code': 'P-M3C-TC-001'},
        '电池': {'cost': 400, 'suggest_price': 620, 'code': 'P-M3C-DC-001'},
    },

    # ==================== Avata / FPV 系列 ====================
    'Avata': {
        '云台电机': {'cost': 120, 'suggest_price': 195, 'code': 'P-AV1-YT-DJ-001'},
        '云台整体': {'cost': 500, 'suggest_price': 750, 'code': 'P-AV1-YT-ZT-001'},
        '图传模块': {'cost': 220, 'suggest_price': 350, 'code': 'P-AV1-TC-001'},
        '电池': {'cost': 150, 'suggest_price': 250, 'code': 'P-AV1-DC-001'},
        '机臂': {'cost': 70, 'suggest_price': 120, 'code': 'P-AV1-JB-001'},
    },
    'Avata 2': {
        '云台电机': {'cost': 135, 'suggest_price': 220, 'code': 'P-AV2-YT-DJ-001'},
        '云台整体': {'cost': 600, 'suggest_price': 900, 'code': 'P-AV2-YT-ZT-001'},
        '图传模块': {'cost': 260, 'suggest_price': 410, 'code': 'P-AV2-TC-001'},
        '电池': {'cost': 180, 'suggest_price': 290, 'code': 'P-AV2-DC-001'},
        '机臂': {'cost': 85, 'suggest_price': 145, 'code': 'P-AV2-JB-001'},
    },
    'FPV': {
        '云台电机': {'cost': 150, 'suggest_price': 240, 'code': 'P-FPV-YT-DJ-001'},
        '云台整体': {'cost': 650, 'suggest_price': 980, 'code': 'P-FPV-YT-ZT-001'},
        '图传模块': {'cost': 300, 'suggest_price': 470, 'code': 'P-FPV-TC-001'},
        '电池': {'cost': 200, 'suggest_price': 320, 'code': 'P-FPV-DC-001'},
    },
    'Neo': {
        '云台电机': {'cost': 100, 'suggest_price': 165, 'code': 'P-NEO-YT-DJ-001'},
        '云台整体': {'cost': 450, 'suggest_price': 680, 'code': 'P-NEO-YT-ZT-001'},
        '图传模块': {'cost': 200, 'suggest_price': 320, 'code': 'P-NEO-TC-001'},
        '电池': {'cost': 130, 'suggest_price': 220, 'code': 'P-NEO-DC-001'},
        '机臂': {'cost': 60, 'suggest_price': 105, 'code': 'P-NEO-JB-001'},
    },

    # ==================== Inspire 系列 ====================
    'Inspire 2': {
        '云台电机': {'cost': 350, 'suggest_price': 550, 'code': 'P-I2-YT-DJ-001'},
        '云台整体': {'cost': 2000, 'suggest_price': 3000, 'code': 'P-I2-YT-ZT-001'},
        '图传模块': {'cost': 800, 'suggest_price': 1200, 'code': 'P-I2-TC-001'},
        '电池': {'cost': 600, 'suggest_price': 900, 'code': 'P-I2-DC-001'},
    },
    'Inspire 3': {
        '云台电机': {'cost': 500, 'suggest_price': 780, 'code': 'P-I3-YT-DJ-001'},
        '云台整体': {'cost': 3500, 'suggest_price': 5200, 'code': 'P-I3-YT-ZT-001'},
        '图传模块': {'cost': 1200, 'suggest_price': 1800, 'code': 'P-I3-TC-001'},
        '摄像头': {'cost': 3000, 'suggest_price': 4500, 'code': 'P-I3-SX-001'},
    },

    # ==================== Matrice 行业机 ====================
    'Matrice 30': {
        '云台电机': {'cost': 400, 'suggest_price': 620, 'code': 'P-M30-YT-DJ-001'},
        '云台整体': {'cost': 2500, 'suggest_price': 3700, 'code': 'P-M30-YT-ZT-001'},
        '图传模块': {'cost': 1000, 'suggest_price': 1500, 'code': 'P-M30-TC-001'},
        '电池': {'cost': 800, 'suggest_price': 1200, 'code': 'P-M30-DC-001'},
    },
    'Matrice 300': {
        '云台电机': {'cost': 450, 'suggest_price': 700, 'code': 'P-M300-YT-DJ-001'},
        '云台整体': {'cost': 3000, 'suggest_price': 4500, 'code': 'P-M300-YT-ZT-001'},
        '图传模块': {'cost': 1200, 'suggest_price': 1800, 'code': 'P-M300-TC-001'},
        '电池': {'cost': 1000, 'suggest_price': 1500, 'code': 'P-M300-DC-001'},
    },
    'Matrice 350': {
        '云台电机': {'cost': 500, 'suggest_price': 780, 'code': 'P-M350-YT-DJ-001'},
        '云台整体': {'cost': 3500, 'suggest_price': 5200, 'code': 'P-M350-YT-ZT-001'},
        '图传模块': {'cost': 1500, 'suggest_price': 2200, 'code': 'P-M350-TC-001'},
        '电池': {'cost': 1200, 'suggest_price': 1800, 'code': 'P-M350-DC-001'},
    },

    # ==================== Agras 植保机 ====================
    'Agras T40': {
        '喷洒泵': {'cost': 800, 'suggest_price': 1200, 'code': 'P-T40-PS-001'},
        '喷头': {'cost': 150, 'suggest_price': 250, 'code': 'P-T40-PT-001'},
        '电池': {'cost': 2500, 'suggest_price': 3800, 'code': 'P-T40-DC-001'},
        '电机': {'cost': 600, 'suggest_price': 900, 'code': 'P-T40-DJ-001'},
    },
    'Agras T50': {
        '喷洒泵': {'cost': 900, 'suggest_price': 1350, 'code': 'P-T50-PS-001'},
        '喷头': {'cost': 180, 'suggest_price': 300, 'code': 'P-T50-PT-001'},
        '电池': {'cost': 3000, 'suggest_price': 4500, 'code': 'P-T50-DC-001'},
        '电机': {'cost': 700, 'suggest_price': 1050, 'code': 'P-T50-DJ-001'},
    },
    'Agras T60': {
        '喷洒泵': {'cost': 1000, 'suggest_price': 1500, 'code': 'P-T60-PS-001'},
        '喷头': {'cost': 200, 'suggest_price': 330, 'code': 'P-T60-PT-001'},
        '电池': {'cost': 3500, 'suggest_price': 5200, 'code': 'P-T60-DC-001'},
        '电机': {'cost': 800, 'suggest_price': 1200, 'code': 'P-T60-DJ-001'},
    },
}

# 报价配置
QUOTE_CONFIG = {
    'labor_cost': 120,        # AI参考报价，人工成本降低
    'profit_margin': 0.20,    # 降低利润率，促进订单
    'price_discount': 0.85,   # AI参考报价统一85折
    'note': 'AI参考报价，实际以检测后报价为准',
    'updated_at': '2026-04-22',
    
    # 价格调整系数（基于闲鱼二手市场规律）
    'cost_factor': {
        'new': 1.0,           # 全新配件
        'refurbished': 0.7,   # 翻新配件
        'used': 0.5,          # 二手配件
    },
    
    # 渠道价格差异
    'channel_factor': {
        'official': 1.2,      # 大疆官方维修
        'authorized': 1.0,    # 授权维修点
        'third_party': 0.8,   # 第三方维修
        'self_repair': 0.6,   # 自修配件
    },
}

def get_price_confidence(drone: str, part: str) -> float:
    """获取价格置信度"""
    # 热门机型
    hot_drones = ['Mini 3 Pro', 'Mini 4 Pro', 'Air 3', 'Air 3S', 'Mavic 3', 'Mavic 3 Pro']
    # 常见机型
    common_drones = ['Mini 3', 'Mini 2', 'Mini SE', 'Air 2s', 'Mavic 2', 'Avata 2', 'Neo']
    
    if drone in hot_drones:
        return 0.9
    elif drone in common_drones:
        return 0.7
    elif drone in PRICING_RULES:
        return 0.5
    else:
        return 0.3

def get_market_price_range(drone: str, part: str) -> dict:
    """获取市场价格区间（基于闲鱼二手市场）"""
    if drone not in PRICING_RULES:
        return None
    
    part_data = PRICING_RULES[drone].get(part)
    if not part_data:
        return None
    
    cost = part_data['cost']
    suggest_price = part_data['suggest_price']
    
    # 闲鱼二手市场参考价（通常是全新配件的40-60%）
    used_price_low = int(cost * 0.4)
    used_price_high = int(cost * 0.6)
    
    # 全新配件参考价（采购价通常是零售价的50-70%）
    new_price_low = int(suggest_price * 0.5)
    new_price_high = int(suggest_price * 0.7)
    
    return {
        'cost': cost,
        'suggest_price': suggest_price,
        'used_price_range': (used_price_low, used_price_high),
        'new_price_range': (new_price_low, new_price_high),
        'confidence': get_price_confidence(drone, part),
        'source': '维修行业经验 + 市场参考',
        'updated_at': '2026-04-22',
    }

if __name__ == "__main__":
    import json
    print("报价规则库概览：")
    print(f"机型数量: {len(PRICING_RULES)}")
    print(f"配置: {json.dumps(QUOTE_CONFIG, ensure_ascii=False, indent=2)}")
    print("\n机型列表：")
    for drone in PRICING_RULES.keys():
        parts_count = len(PRICING_RULES[drone])
        print(f"  {drone}: {parts_count} 种配件")
    
    # 测试价格查询
    print("\n" + "="*60)
    print("价格查询示例：")
    print("="*60)
    
    test_cases = [
        ('Mini 3 Pro', '云台电机'),
        ('Air 3', '图传模块'),
        ('Mavic 3', '云台整体'),
    ]
    
    for drone, part in test_cases:
        result = get_market_price_range(drone, part)
        if result:
            print(f"\n{drone} - {part}:")
            print(f"  成本价: ¥{result['cost']}")
            print(f"  建议价: ¥{result['suggest_price']}")
            print(f"  二手市场参考: ¥{result['used_price_range'][0]}-¥{result['used_price_range'][1]}")
            print(f"  全新配件参考: ¥{result['new_price_range'][0]}-¥{result['new_price_range'][1]}")
            print(f"  置信度: {result['confidence']}")
