#!/usr/bin/env python3
"""
AI Parser - 维修助手自然语言解析引擎
解析用户输入，提取意图和实体
"""

import re
import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

@dataclass
class ParseResult:
    """解析结果"""
    intent: str  # 意图: quote/stock_in/stock_out/query/create_order
    confidence: float  # 置信度
    entities: Dict  # 提取的实体
    raw_input: str  # 原始输入
    response: str  # AI回复文本

class RepairAIParser:
    """维修AI解析器"""
    
    def __init__(self, db_path: str = None):
        self.db_path = db_path
        
        # 全系列机型别名映射（更具体的机型放在前面）
        self._drone_aliases = [
            # Mini series
            (['mini4pro', '迷你4pro', 'm4p'], 'Mini 4 Pro'),
            (['mini4k', '迷你4k', 'm4k'], 'Mini 4K'),
            (['mini3pro', '迷你3pro', 'mini3p', 'm3p'], 'Mini 3 Pro'),
            (['mini3', '迷你3'], 'Mini 3'),
            (['mini2se', '迷你2se', 'm2se'], 'Mini 2 SE'),
            (['mini2', '迷你2'], 'Mini 2'),
            (['minise', '迷你se', 'mse'], 'Mini SE'),
            (['mini', '迷你'], 'Mini'),
            # Air series
            (['air3s', 'airs3'], 'Air 3S'),
            (['air3', 'airiii'], 'Air 3'),
            (['air2s', 'airs', 'a2s'], 'Air 2s'),
            (['air2', 'airii'], 'Air 2'),
            # Mavic series
            (['mavic3pro', '御3pro', 'mavic3p', '御3p'], 'Mavic 3 Pro'),
            (['mavic3classic', '御3classic', 'mavic3c', '御3c'], 'Mavic 3 Classic'),
            (['mavic3cine'], 'Mavic 3 Cine'),
            (['mavic3enterprise', 'mavic3e', 'mavic3t', 'mavic3m'], 'Mavic 3 Enterprise'),
            (['mavic3', '御3'], 'Mavic 3'),
            (['mavic2zoom', '御2zoom', 'mavic2z', '御2z'], 'Mavic 2 Zoom'),
            (['mavic2pro', '御2pro', 'mavic2p', '御2p'], 'Mavic 2 Pro'),
            (['mavic2', '御2', '御二'], 'Mavic 2'),
            # Inspire
            (['inspire3', '悟3'], 'Inspire 3'),
            (['inspire2', '悟2'], 'Inspire 2'),
            # Matrice
            (['matrice350', 'm350', 'm350rtk'], 'Matrice 350'),
            (['matrice300', 'm300', 'm300rtk'], 'Matrice 300'),
            (['matrice30', 'm30', 'm30t'], 'Matrice 30'),
            # Avata / FPV / Neo
            (['avata2', '阿凡达2'], 'Avata 2'),
            (['avata', '阿凡达'], 'Avata'),
            (['fpv'], 'FPV'),
            (['neo'], 'Neo'),
            # Agriculture
            (['agrast60', 't60'], 'Agras T60'),
            (['agrast50', 't50'], 'Agras T50'),
            (['agrast40', 't40'], 'Agras T40'),
        ]
        
        # 配件关键词映射（从具体到一般，避免重复匹配）
        self.part_patterns = {
            '云台电机': ['云台电机', 'gimbal motor', 'gimbal_motor'],
            '云台排线': ['云台排线', 'flex cable'],
            '云台整体': ['云台总成', '云台整体', 'gimbal assembly'],
            '图传模块': ['图传', '图传模块', 'transmission', 'vtx'],
            '电调': ['电调', 'esc'],
            '飞控': ['飞控', 'flight controller', 'fc'],
            '电池': ['电池', 'battery'],
            '机臂': ['机臂', '折叠臂', 'arm'],
            '桨叶': ['桨叶', '螺旋桨', '桨', 'propeller'],
            '摄像头': ['摄像头', '相机模组', 'camera'],
            '镜头': ['镜头', 'lens'],
            '外壳': ['外壳', '机壳', '上壳', '下壳', 'shell'],
            '遥控器': ['遥控器', '遥控', 'controller'],
            '充电器': ['充电器', '充电', 'charger'],
        }
        
        # 意图关键词
        self.intent_patterns = {
            'quote': ['报价', '多少钱', '价格', '费用', '怎么收费', '修一下多少钱', '坏了', '坏了修', '维修要', '换一个'],
            'stock_in': ['入库', '进货', '添加', '新增', '采购'],
            'stock_out': ['出库', '使用', '消耗', '用了', '消耗掉'],
            'query': ['查询', '查', '看看', '有多少', '库存'],
            'create_order': ['新建', '创建', '新订单', '下单', '登记'],
        }
        
    def parse(self, text: str) -> ParseResult:
        """解析用户输入"""
        text_lower = text.lower().strip()
        
        # 1. 识别意图
        intent, confidence = self._detect_intent(text_lower)
        
        # 2. 提取实体
        entities = {
            'drone': self._extract_drone(text_lower),
            'parts': self._extract_parts(text_lower),
            'quantity': self._extract_quantity(text),
            'action': self._extract_action(text_lower),
        }
        
        # 3. 生成回复
        response = self._generate_response(intent, entities, text)
        
        return ParseResult(
            intent=intent,
            confidence=confidence,
            entities=entities,
            raw_input=text,
            response=response
        )
    
    def _detect_intent(self, text: str) -> Tuple[str, float]:
        """识别用户意图"""
        scores = {}
        
        for intent, keywords in self.intent_patterns.items():
            score = 0
            for keyword in keywords:
                if keyword in text:
                    score += 1
            scores[intent] = score
        
        if not scores or max(scores.values()) == 0:
            return 'chat', 0.5
        
        best_intent = max(scores, key=scores.get)
        return best_intent, min(1.0, scores[best_intent] * 0.3 + 0.5)
    
    def _extract_drone(self, text: str) -> Optional[str]:
        """提取机型"""
        if not text:
            return None
        # 统一清洗：去首尾空格、去中间空格及常见标点、转小写
        m = re.sub(r'\s+|[，,。\.！!？\?、\-_/]', '', str(text).strip().lower())
        for aliases, canonical in self._drone_aliases:
            if any(alias in m for alias in aliases):
                return canonical
        return None
    
    def _extract_parts(self, text: str) -> List[Dict]:
        """提取配件信息"""
        parts = []
        found_parts = set()
        
        for part_name, keywords in self.part_patterns.items():
            for keyword in keywords:
                if keyword in text and part_name not in found_parts:
                    parts.append({
                        'name': part_name,
                        'keyword': keyword
                    })
                    found_parts.add(part_name)
                    break
        
        return parts
    
    def _extract_quantity(self, text: str) -> int:
        """提取数量"""
        match = re.search(r'(\d+)\s*[个台块支套]', text)
        if match:
            return int(match.group(1))
        
        match = re.search(r'(\d+)(?!\S)', text)
        if match:
            return int(match.group(1))
        
        chinese_nums = {
            '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5,
            '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
        }
        for char, num in chinese_nums.items():
            if char in text:
                return num
        
        return 1
    
    def _extract_action(self, text: str) -> str:
        """提取操作动作"""
        if '换' in text or '更换' in text:
            return 'replace'
        elif '修' in text or '维修' in text:
            return 'repair'
        elif '检测' in text or '检查' in text:
            return 'inspect'
        elif '校准' in text:
            return 'calibrate'
        return 'unknown'
    
    def _generate_response(self, intent: str, entities: Dict, raw_text: str) -> str:
        """生成AI回复"""
        drone = entities.get('drone')
        parts = entities.get('parts', [])
        quantity = entities.get('quantity', 1)
        
        if intent == 'quote':
            if not drone:
                return "请告诉我具体的机型，比如 Mini 3 Pro、Air 3、Mavic 3 等。"
            if not parts:
                return f"{drone}需要维修什么部件呢？比如云台电机、图传模块、电池、机臂等。"
            
            # 去重配件（避免云台电机+云台整体重复）
            unique_parts = []
            seen_names = set()
            for p in parts:
                if p['name'] not in seen_names:
                    unique_parts.append(p)
                    seen_names.add(p['name'])
            
            parts_str = '、'.join([p['name'] for p in unique_parts])
            return f"正在为您查询 {drone} 的 {parts_str} 价格..."
        
        elif intent == 'stock_in':
            part_names = '、'.join([p['name'] for p in parts]) if parts else '配件'
            return f"确认入库 {quantity} 个 {part_names}？"
        
        elif intent == 'stock_out':
            part_names = '、'.join([p['name'] for p in parts]) if parts else '配件'
            return f"确认出库 {quantity} 个 {part_names}？"
        
        elif intent == 'query':
            if parts:
                return f"正在查询 {parts[0]['name']} 的库存..."
            return "请问要查询什么配件的库存？"
        
        elif intent == 'create_order':
            return "请提供客户信息和故障描述，我来帮您创建工单。"
        
        return "我是您的维修助手，可以帮您：\n• 生成维修报价\n• 查询配件库存\n• 创建新工单\n• 管理配件出入库"


# 配件价格数据库（已迁移到独立文件）
from pricing_rules_db import PRICING_RULES as DEFAULT_PARTS_DB, QUOTE_CONFIG

# 保留兼容性
if not DEFAULT_PARTS_DB:
    DEFAULT_PARTS_DB = {
        'Mini 3 Pro': {
            '云台电机': {'cost': 145, 'suggest_price': 230, 'code': 'P-M3P-YT-DJ-001'},
            '云台排线': {'cost': 35, 'suggest_price': 80, 'code': 'P-M3P-YT-PX-001'},
            '云台整体': {'cost': 680, 'suggest_price': 980, 'code': 'P-M3P-YT-ZT-001'},
            '图传模块': {'cost': 280, 'suggest_price': 450, 'code': 'P-M3P-TC-001'},
            '电调': {'cost': 120, 'suggest_price': 200, 'code': 'P-M3P-DD-001'},
            '飞控': {'cost': 380, 'suggest_price': 580, 'code': 'P-M3P-FK-001'},
            '电池': {'cost': 180, 'suggest_price': 299, 'code': 'P-M3P-DC-001'},
            '机臂': {'cost': 85, 'suggest_price': 150, 'code': 'P-M3P-JB-001'},
            '桨叶': {'cost': 25, 'suggest_price': 49, 'code': 'P-M3P-JY-001'},
            '摄像头': {'cost': 450, 'suggest_price': 680, 'code': 'P-M3P-SX-001'},
            '镜头': {'cost': 320, 'suggest_price': 520, 'code': 'P-M3P-JT-001'},
            '外壳': {'cost': 120, 'suggest_price': 200, 'code': 'P-M3P-WK-001'},
        },
        'Air 3': {
            '云台电机': {'cost': 165, 'suggest_price': 260, 'code': 'P-A3-YT-DJ-001'},
            '云台排线': {'cost': 45, 'suggest_price': 95, 'code': 'P-A3-YT-PX-001'},
            '云台整体': {'cost': 850, 'suggest_price': 1280, 'code': 'P-A3-YT-ZT-001'},
            '图传模块': {'cost': 350, 'suggest_price': 550, 'code': 'P-A3-TC-001'},
            '电调': {'cost': 150, 'suggest_price': 250, 'code': 'P-A3-DD-001'},
            '飞控': {'cost': 480, 'suggest_price': 720, 'code': 'P-A3-FK-001'},
            '电池': {'cost': 220, 'suggest_price': 359, 'code': 'P-A3-DC-001'},
            '机臂': {'cost': 120, 'suggest_price': 200, 'code': 'P-A3-JB-001'},
            '桨叶': {'cost': 35, 'suggest_price': 69, 'code': 'P-A3-JY-001'},
        },
        'Mavic 3': {
            '云台电机': {'cost': 220, 'suggest_price': 350, 'code': 'P-M3-YT-DJ-001'},
            '云台整体': {'cost': 1200, 'suggest_price': 1680, 'code': 'P-M3-YT-ZT-001'},
            '图传模块': {'cost': 450, 'suggest_price': 680, 'code': 'P-M3-TC-001'},
            '飞控': {'cost': 650, 'suggest_price': 980, 'code': 'P-M3-FK-001'},
            '电池': {'cost': 380, 'suggest_price': 599, 'code': 'P-M3-DC-001'},
        },
    }


class QuoteCalculator:
    """报价计算器"""
    
    def __init__(self, parts_db: Dict = None):
        self.parts_db = parts_db or DEFAULT_PARTS_DB
        # 从配置文件加载参数
        config = QUOTE_CONFIG if 'QUOTE_CONFIG' in dir() else {
            'labor_cost': 120,
            'profit_margin': 0.20,
            'price_discount': 0.85,
        }
        self.labor_cost = config['labor_cost']  # AI参考报价，降低人工成本
        self.profit_margin = config['profit_margin']  # 降低利润率，促进订单
        self.price_discount = config['price_discount']  # AI参考报价统一85折
    
    def calculate_quote(self, drone: str, parts: List[str], quantity: int = 1) -> Dict:
        """计算报价（AI参考价，已优化促进订单）"""
        drone_data = self.parts_db.get(drone, {})
        
        quote_items = []
        total_cost = 0
        total_price = 0
        
        for part_name in parts:
            part_data = drone_data.get(part_name)
            if part_data:
                item_cost = part_data['cost'] * quantity
                # AI参考价：建议价的85折
                item_price = int(part_data['suggest_price'] * self.price_discount) * quantity
                
                quote_items.append({
                    'part_name': part_name,
                    'part_code': part_data['code'],
                    'quantity': quantity,
                    'unit_cost': part_data['cost'],
                    'unit_price': int(part_data['suggest_price'] * self.price_discount),
                    'original_price': part_data['suggest_price'],
                    'cost': item_cost,
                    'price': item_price,
                })
                
                total_cost += item_cost
                total_price += item_price
        
        labor_total = self.labor_cost
        total_cost += labor_total
        total_price += labor_total
        
        profit = total_price - total_cost
        profit_margin = (profit / total_price * 100) if total_price > 0 else 0
        
        return {
            'drone': drone,
            'items': quote_items,
            'labor_cost': labor_total,
            'total_cost': total_cost,
            'total_price': total_price,
            'profit': profit,
            'profit_margin': round(profit_margin, 1),
            'currency': 'CNY',
            'note': 'AI参考报价，实际以检测后报价为准',
        }
    
    def get_part_info(self, drone: str, part_name: str) -> Optional[Dict]:
        """获取配件信息"""
        drone_data = self.parts_db.get(drone, {})
        return drone_data.get(part_name)
    
    def search_parts(self, keyword: str) -> List[Dict]:
        """搜索配件"""
        results = []
        for drone, parts in self.parts_db.items():
            for part_name, part_data in parts.items():
                if keyword.lower() in part_name.lower() or keyword.lower() in part_data['code'].lower():
                    results.append({
                        'drone': drone,
                        'part_name': part_name,
                        **part_data
                    })
        return results


if __name__ == "__main__":
    parser = RepairAIParser()
    calculator = QuoteCalculator()
    
    test_inputs = [
        "Mini3云台电机坏了，报个价",
        "Air3换图传模块多少钱",
        "入库10个Mini3云台电机",
        "查询云台电机库存",
        "新建一个工单",
    ]
    
    print("=" * 60)
    print("AI Parser 测试")
    print("=" * 60)
    
    for text in test_inputs:
        result = parser.parse(text)
        print(f"\n输入: {text}")
        print(f"意图: {result.intent} (置信度: {result.confidence:.2f})")
        print(f"实体: {json.dumps(result.entities, ensure_ascii=False)}")
        print(f"回复: {result.response}")
        
        if result.intent == 'quote' and result.entities.get('drone') and result.entities.get('parts'):
            drone = result.entities['drone']
            parts = [p['name'] for p in result.entities['parts']]
            quote = calculator.calculate_quote(drone, parts)
            print(f"报价: 成本¥{quote['total_cost']} → 售价¥{quote['total_price']} (利润{quote['profit_margin']}%)")
    
    print("\n" + "=" * 60)
